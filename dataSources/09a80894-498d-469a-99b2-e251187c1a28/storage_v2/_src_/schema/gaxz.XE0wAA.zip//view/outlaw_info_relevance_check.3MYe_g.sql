create view outlaw_info_relevance_check as
  select `gaxz`.`outlaw_info`.`id_card`               AS `id_card`,
         `gaxz`.`outlaw_info`.`submit_time`           AS `submit_time`,
         `gaxz`.`outlaw_info`.`submit_police_station` AS `submit_police_station`,
         `gaxz`.`outlaw_info`.`first_police_station`  AS `first_police_station`,
         `gaxz`.`outlaw_info`.`phone`                 AS `phone`,
         `gaxz`.`outlaw_info_check`.`user`            AS `user`,
         `gaxz`.`outlaw_info_check`.`outlaw_id_card`  AS `outlaw_id_card`,
         `gaxz`.`outlaw_info_check`.`is_check`        AS `is_check`
  from (`gaxz`.`outlaw_info` join `gaxz`.`outlaw_info_check`)
  where (`gaxz`.`outlaw_info`.`id_card` = `gaxz`.`outlaw_info_check`.`outlaw_id_card`);

